
from pymongo import MongoClient
from bson import objectid
import csv

# client = MongoClient('mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-prod-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Prod-shard-0&authSource=admin')
# db = client['coin-db']

client = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db = client['coin-db']

def get_users():
    not_valid = [
        "Ecobonuz",
        "Saritur",
        "Saritur Ipatinga",
        "Saritur Itauna",
        "Saritur Lavras",
        "Saritur Timóteo",
        "Saritur Varginha",
        "Fabrifacil"
    ]
    users = db.users.find(
        {'name': {'$nin': not_valid}},
        # {'name':  {'$in': ["Saritur"]}},
        {'_id': 1}, no_cursor_timeout=True).limit(5)


# def get_users():
#     users = db.users.find({}, {'_id': 1}, no_cursor_timeout=True)
    with open('meuarquivo.csv', 'w', newline='') as csvfile:
        fieldnames = [
            '_id',
            'nome',
            # 'status',
            'cpf',
            'celular',
            'cidade',
            'cards',
            'cardsNumber',
            'saldo',
            'lastPoint',
            'funcionario',
            'createDate',
            'email',
            'partner'

        ]

        csv_writer = csv.DictWriter(
            csvfile, delimiter=';', fieldnames=fieldnames)
        for user in users:
            result = db.users.aggregate([
                {
                    '$match': {
                        '_id': user['_id']
                    }
                },
                {'$lookup': {
                    'from': 'wallets',
                    'localField': '_id',
                    'foreignField': 'user',
                    'as': 'walletInfo'
                }},
                {'$unwind': {'path': '$walletInfo', 'preserveNullAndEmptyArrays': True}},
                {'$project': {
                    'walletInfo.chain': 0, 'menu': 0
                }},

                {'$lookup': {
                    'from': 'transactions',
                    'localField': 'walletInfo._id',
                    'foreignField': 'walletId',
                    'as': 'transactionInfo'
                }},
                {'$match': {
                    'transactionInfo.description': 'reward'
                }},
                {'$addFields': {
                    'lastPoint': {'$arrayElemAt': ['$transactionInfo', -1]}
                }},
                {'$unwind': {'path': '$lastPoint', 'preserveNullAndEmptyArrays': True}},
                {'$lookup': {
                    'from': 'bus_cards',
                    'localField': '_id',
                    'foreignField': 'user',
                    'as': 'cardInfo'
                }},
                {'$lookup': {
                    'from': 'users',
                    'localField': 'cardInfo.partner',
                    'foreignField': '_id',
                    'as': 'partnerInfo'
                 }},
                # {'$project': {
                #      'cardInfo.number': 1
                #      'cardInfo.status': 1
                #  }},
                {'$project': {
                    'nome': '$name',
                    # 'status': 1,
                    'cpf': '$ein',
                    'celular': '$phone',
                    'email': '$email',
                    'cidade': '$city',
                    'cards': '$cardInfo',
                    'cards': '$cardInfo.status',

                    'cardsNumber': '$cardInfo.number',
                    'saldo': '$walletInfo.balance',
                    'lastPoint': '$lastPoint',
                    'createDate': '$createdAt',
                    'partner': '$partnerInfo.name',

                    # 'lastPoint': '$lastPoint.details',
                    # 'lastPoint': '$lastPoint.createdAt',
                    'funcionario': {'$ifNull': ["$isPartnerEmployee", False]}
                }}
            ], allowDiskUse=True)

            result = [r for r in result]
            if result:
                result = result[0]
                csv_writer.writerow(result)


if __name__ == '__main__':
    import time

    init = time.time()
    get_users()
    print("terminou:", time.time() - init)
