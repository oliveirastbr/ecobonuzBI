from pymongo import MongoClient


client = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")


def get_db():
    return client['coin-db']


def close_conn():
    client.close()
