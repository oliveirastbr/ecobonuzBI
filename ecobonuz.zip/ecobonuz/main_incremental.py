from pymongo import MongoClient
import schedule
import time
import bi_store_balance_graph as store


from bson.objectid import ObjectId
import datetime

client_dest = MongoClient('mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-prod-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Prod-shard-0&authSource=admin')
db_dest = client_dest['coin-db']

# client_orig = MongoClient(
#     "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
# db_orig = client_orig['coin-db']


client_dest = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_dest = client_dest['ecobonuzbi']

def get_store():
    db_dest.reportStoreBalance.remove({})
    store.create_store_balance_graph()
# descomnetar quando rodar automático
# schedule.every(1).minutes.do(get_store)
schedule.every().day.at("05:00").do(get_store())
# comentar quando rodar automático
# if __name__ == '__main__':
#descomenta quando rodar eutomático
while True:
    # schedule.run_pending()
    time.sleep(1)
    get_store()
