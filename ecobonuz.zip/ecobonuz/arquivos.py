from encode_decode_json import encode_complex_objects


def escreve_arquivo(dir, nome_arquivo, linha):
    with open(dir + nome_arquivo, 'a+') as arquivo:
        arquivo.write(encode_complex_objects(linha) + "\n")
