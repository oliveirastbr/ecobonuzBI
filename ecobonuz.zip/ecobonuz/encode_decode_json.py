from bson import ObjectId
import datetime


def encode_complex_objects(z):
    if isinstance(z, (ObjectId, datetime.datetime, dict,)):
        return z.__str__()
    else:
        type_name = z.__class__.__name__
        raise TypeError(f"Object of type '{type_name}' is not JSON serializable")
