from pymongo import MongoClient
from bson.objectid import ObjectId
import pendulum
from datetime import datetime, timedelta

# client_orig = MongoClient('mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-prod-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Prod-shard-0&authSource=admin')
# db_orig = client_orig['coin-db']

client_orig = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_orig = client_orig['coin-db']


client_dest = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_dest = client_dest['test']


def create_balance():
    startDate = datetime(year=2018,month=3,day=1, hour=0, minute=0, second=0)
    dateFinal = datetime(year=2018, month=3,day=2, hour=23, minute=59, second=59)
    dateActual = datetime.now()
    agora = datetime.now()
    print('test1')

    while startDate < dateActual:
        result = db_orig.transactions.aggregate([
            {'$match': {'createdAt': {'$gte': startDate, '$lte': dateFinal},
                        'description': {'$nin': ['initial', 'issuance', 'transferForce']}}},
            {'$lookup': {'from': 'wallets', 'localField': 'walletId', 'foreignField': '_id', 'as': 'wallet'}},
            {'$unwind': "$wallet"},
            {'$project': {'wallet.chain': 0}},
            {'$lookup': {'from': 'users', 'localField': 'wallet.user', 'foreignField': '_id', 'as': 'user'}},
            {'$unwind': "$user"},
            {'$match':{'user.isPartner': True}},
            {'$group': {
                '_id': {
                    'partner': '$walletId',
                    'description': '$description',
                    'day': {'$substr': ['$createdAt', 8, 2]},
                    'month': {'$substr': ['$createdAt', 5, 2]},
                    'year': {'$substr': ['$createdAt', 0, 4]}
            },
                'totalAccumulate':  {'$sum': {'$cond': [{'$eq': ['$type', 'addBalance']}, '$transactionAmount', 0]}},
                'totalRescues':  {'$sum': {'$cond': [{'$eq': ['$type', 'removeBalance']}, '$transactionAmount', 0]}},
                'coinsAvaliable': {'$sum': {'$cond': [{'$eq': ['$description', 'credit']}, '$transactionAmount', 0]}},
                'partner': {'$first': {'id': '$user._id', 'name': '$user.name'}},
                'data': {'$first': {'$concat': [{'$substr': ['$createdAt', 0, 4]}, '-', {'$substr': ['$createdAt', 5, 2]}, '-', {'$substr': ['$createdAt', 8, 2]}]}}
               }
            },
            {'$project': {
                '_id': False,
                'partner.id':  '$partner.id',
                'partner.name': '$partner.name',
                'description': 1,
                'totalAccumulate': 1,
                'totalRescues': 1,
                'coinsAvaliable': 1,
                'transactionsQuantity': 1,
                # 'date': {'$dateFromString': {'dateString': '$date'}}
                'date': '$date'
                }
            }
        ])
        # print('balance', startDate.toString(), dateFinal.toString(), result.length)
        # db_dest.bi_ticketMedio.insert(result)
        startDate = startDate + timedelta(days=1)
        dateFinal = dateFinal + timedelta(days=1)
        # dateFinal.setDate(dateFinal.getDate() + 1)
        resp = []
        i = 0
        for r in result:
            resp.append(r)
            i = i + 1
            if (i % 1000) == 0:
                print(i)
            if i == 250:
                print('Starting insert')
                db_dest.testeBalanceBeta.insert(r)
                i = 0
                resp = []

            # try:
            #     r['transferedAt'] = agora
            #     db_dest.testeBalanceBeta.insert(r)
            #     print(r)
            # except Exception as err:
            #     print('did not copy card', err)


if __name__ == '__main__':
    import time
    init = time.time()
    create_balance()
    print("terminou:", time.time() - init)



