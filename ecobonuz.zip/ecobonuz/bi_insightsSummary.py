from pymongo import MongoClient
from bson.objectid import ObjectId
import datetime
import time
import arrow

# client_orig = MongoClient('mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-prod-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Prod-shard-0&authSource=admin')
# db_orig = client_orig['coin-db']

client_orig = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_orig = client_orig['coin-db']


client_dest = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/test?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_dest = client_dest['test']


def get_bus_cards():
    agora = datetime.datetime.now()
    # db_dest.bus_cards.remove({})
    for doc in db_orig.users.aggregate([
        {'$group': {
            '_id': 'null',
            'clientes': {'$sum': 1}
        }
        },
        {'$project': {
            '_id': 0}
        }
        ]):
        try:
            doc['transferedAt'] = agora
            db_dest.insightsSummary.insert(doc)
            print(doc)
        except Exception as err:
            print('did not copy card', err)


if __name__ == '__main__':
    get_bus_cards()
    # schedule.every().day.at("01:30").do(get_transactions)

#
#     for r in result:
#         try:
#             r['transferedAt'] = agora
#             db_dest.testeUsers.insert(r)
#             print(r)
#         except Exception as err:
#             print('did not copy card', err)
#
#
# if __name__ == '__main__':
#     import time
#     init = time.time()
#     create_reports_accumulate()
#     print("terminou:", time.time() - init)