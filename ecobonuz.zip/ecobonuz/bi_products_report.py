from pymongo import MongoClient
from bson.objectid import ObjectId
import datetime
import time

# client_orig = MongoClient('mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-prod-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Prod-shard-0&authSource=admin')
# db_orig = client_orig['coin-db']

client_orig = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_orig = client_orig['coin-db']


client_dest = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_dest = client_dest['ecobonuzbi']


def create_products():
    agora = datetime.datetime.now()
    result = db_orig.products.aggregate([
        {'$lookup': {
            'from': 'users', 'localField': 'partner',
            'foreignField': '_id', 'as': 'partner'
        }},
        {'$unwind': '$partner'},
        {'$project': {
            '_id': 1,
            'label': 1,
            'type': 1,
            'partner': ['$partner._id','$partner.name'],
            'subCategories':['$_id', '$name'],
            'typePrice': 'null',
            'typeShippingCost': 'null',
            'createdAt': {
                '$dateToString': {
                    'format': "%d/%m/%Y",
                    'date': "$createdAt"
                }
            },

        }}
    ])

    for r in result:
        try:
            r['transferedAt'] = agora
            db_dest.reportsProducts.insert(r)
            print(r)
        except Exception as err:
            print('did not copy card', err)


if __name__ == '__main__':
    import time
    init = time.time()
    create_products()
    print("terminou:", time.time() - init)