from pymongo import MongoClient
from bson.objectid import ObjectId
import datetime
import time

# client_orig = MongoClient('mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-prod-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Prod-shard-0&authSource=admin')
# db_orig = client_orig['coin-db']

client_orig = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_orig = client_orig['coin-db']


client_dest = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_dest = client_dest['coin-db']


def create_users_report():
    agora = datetime.datetime.now()

    quantity = db_orig.users.find({}).count()
    limit = 10
    skip = 0
    loops = int((quantity - 1) / limit + 1)

    for x in range(loops):
        print('loops')
        if x > 0:
            skip = x * limit
        else:
            skip = 0

        if (x + 1) == loops and quantity % limit != 0:
            limit = quantity % limit

        result = db_orig.users.aggregate([
            {'$match': {'name': {'$nin': ["Ecobonuz", "Saritur", "Saritur Ipatinga", "Saritur Itauna",
                                          "Saritur Lavras", "Saritur Timóteo", "Saritur Varginha", "Fabrifacil",
                                          "Sacolão Central - Esperança","POLICARD SYSTEMS E SERVICOS S/A",
                                          "Connection Suplementos", "Teste Partner", "Teste", "Sacolão Central - Veneza Ll",
                                          "Sacolão Central - Jardim Panorama", "Multiclínica Mais Saúde", "Is2B",
                                          "Minutrade","Tele Gás E Água Mineral Barbosa","Voucher","transnorte",
                                          "AUTOTRANS TRANSPORTES URBANOS E RODOVIARIOS LTDA", "Wifi", "Pentagrama"]}}},
            {'$skip': skip},
            {'$limit': limit},
            {'$lookup': {
                'from': 'wallets','localField': '_id',
                'foreignField': 'user', 'as': 'walletInfo'}},
            {'$unwind': {'path': '$walletInfo', 'preserveNullAndEmptyArrays': True}},
            {'$project': {'walletInfo.chain': 0, 'menu': 0}},
            {'$lookup': {
                'from': 'transactions',
                'let': {'wallet': '$walletInfo._id'},
                'pipeline': [
                    {'$match':
                        {'$expr':
                            {'$and':
                            [{'$eq': ['$walletId', '$$wallet']}, {'$eq': ['$description', 'reward']},
                             {'$eq': ['$type', 'addBalance']}]}}
                     }],
                'as': 'transactionInfo'}},
            # {'$match':{'transactionInfo.description': 'reward', 'transactionInfo.type': 'addBalance'}},
            {'$addFields': {'lastPoint': {'$arrayElemAt': ['$transactionInfo', -1]}}},
            {'$unwind': {'path': '$lastPoint', 'preserveNullAndEmptyArrays': True}},
            # {'$match': {'partner._id': {'$ne': 'ObjectId("5be96d50d103ce0013046420")'}}},
            {'$lookup': {'from': 'bus_cards', 'localField': '_id', 'foreignField': 'user', 'as': 'cardInfo'}},
            {'$lookup': {
                'from': 'users', 'localField': 'cardInfo.partner',
                'foreignField': '_id', 'as': 'partner'}},
            {'$unwind': {'path': '$partner', 'preserveNullAndEmptyArrays': True}},
            {'$project': {
                '_id': '$_id',
                'name': '$name',
                'ein': '$ein',
                'phone': '$phone',
                'email': '$email',
                'createdAt': '$createdAt',
                'partner.id': {'$toString': '$partner._id'},
                'partner.name': '$partner.name',
                'registered': {'$ifNull': [False, 'registered']},
                'profileCompleted': {'$ifNull': ["$profileCompleted", False]},
            }}
        ])

        for r in result:
            try:
                r['transferedAt'] = agora
                db_dest.reportsUsersBeta.insert(r)
                print(r)
            except Exception as err:
                print('did not copy card', err)


if __name__ == '__main__':
    import time
    init = time.time()
    create_users_report()
    print("terminou:", time.time() - init)