from pymongo import MongoClient
from bson.objectid import ObjectId
import datetime
import time
import arrow

client_orig = MongoClient('mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-prod-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Prod-shard-0&authSource=admin')
db_orig = client_orig['coin-db']

# client_orig = MongoClient(
#     "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
# db_orig = client_orig['coin-db']


client_dest = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_dest = client_dest['test']


def create_reports_accumulate():
    agora = datetime.datetime.now()
    result = db_orig.transactions.aggregate([
        {'$match': {'description': 'reward', 'type': 'addBalance'}},
        {'$lookup': {
            'from': 'wallets', 'localField': 'toWallet',
            'foreignField': '_id', 'as': 'wallet'
        }},
        {'$unwind': '$wallet'},
        {'$project': {'wallet.chain': 0}},
        {'$lookup': {
            'from': 'users', 'localField': 'wallet.user',
            'foreignField': '_id', 'as': 'partner'
        }},
        {'$unwind': '$partner'},
        {'$group': {
            '_id': {
                'partner': '$partner._id',
                'description': '$description',
                'description': '$tipo',
                'day': {'$substr': ['$createdAt', 8, 2]},
                'month': {'$substr': ['$createdAt', 5, 2]},
                'year': {'$substr': ['$createdAt', 0, 4]}
                },
            'partner': {'$first': {'id': '$partner._id', 'name': '$partner.name'}},
            'description': {'$last': '$description'},
            # 'realValue': {'$sum': {'$toDouble': '$details.paidValue'}},
            'realValue': {'$sum':  '$details.paidValue'},
            'coinValue': {'$sum': '$transactionAmount'},
            'transactionsQuantity': {'$sum': 1},
            'date': {'$first': {'$concat': [{'$substr': ['$createdAt', 0, 4]}, '-', {'$substr': ['$createdAt', 5, 2]}, '-', {'$substr': ['$createdAt', 8, 2]}]}}
            }
        },
        {'$project': {
            '_id': False,
            # 'partner.id': {'$toString': '$partner.id'},
            'partner.id':  '$partner.id',
            'partner.name': '$partner.name',
            'description': 1,
            'realValue': 1,
            'coinValue': 1,
            'transactionsQuantity': 1,
            'date': '$date'
            # 'date': {'$dateFromString': {'dateString': '$date'}}
        }}
    ])
    for r in result:
        try:
            r['transferedAt'] = agora
            db_dest.reportsAccumulate.insert(r)
            print(r)
        except Exception as err:
            print('did not copy card', err)


if __name__ == '__main__':
    import time
    init = time.time()
    create_reports_accumulate()
    print("terminou:", time.time() - init)