from pymongo import MongoClient
from bson.objectid import ObjectId
import datetime

client_orig = MongoClient('mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-prod-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Prod-shard-0&authSource=admin')
db_orig = client_orig['coin-db']

# client_orig = MongoClient(
#     "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
# db_orig = client_orig['coin-db']


client_dest = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_dest = client_dest['ecobonuzbi']


def create_user_ebz_reports():
    not_valid = [
        # "Ecobonuz",
        # "Saritur",
        # "Saritur Ipatinga",
        # "Saritur Itauna",
        # "Saritur Lavras",
        # "Saritur Timóteo",
        # "Saritur Varginha",
        # "Fabrifacil"

    ]
    users = db_orig.users.find(
        # {'name': {'$nin': not_valid}},
        # {'_id': 1}, no_cursor_timeout=True).limit(5)
        {'name': {'$nin': not_valid}}, no_cursor_timeout=True).limit(5)

    for user in users:
        wallet = db_orig.wallets.find_one({'user': user['_id']})
        if wallet:
            data_ultima = db_dest.bi_users.find({}, {'_id': 0, 'transferedAt': 1})\
                .sort([('transferedAt', -1)]).limit(1)

            result = db_orig.transactions.aggregate([
                {
                    '$match': {
                        'type': 'addBalance',
                        'description': 'reward',
                        'walletId': ObjectId(wallet['_id']),
                        # 'createdAt': {'$gt': list(data_ultima)[0]["transferedAt"]}
                    }
                },
                {
                    '$lookup': {
                        'from': 'wallets', 'localField': 'walletId',
                        'foreignField': '_id', 'as': 'walletInfo'
                    }
                },
                {'$unwind': '$walletInfo'},
                {'$project': {'walletInfo.chain': 0}},
                {
                    '$project': {
                        'userId': '$walletInfo.user',
                        'walletId': '$walletInfo._id',
                        'createdAtMonth': {'$month': '$createdAt'},
                        'createdAtYear': {'$year': '$createdAt'},
                        'transactionAmount': 1,
                        'createdAt': 1
                    }
                },
                {
                    '$group': {
                        '_id': '$createdAtMonth',
                        'userId': {'$first': '$userId'},
                        'walletId': {'$first': '$walletId'},
                        'totalBalance': {'$sum': '$transactionAmount'},
                        'mes': {'$first': '$createdAtMonth'},
                        'ano': {'$first': '$createdAtYear'}
                    }
                },
                {'$project': {'_id': 0}},
                {
                    '$project': {
                        'userId': 1,
                        'walletId': 1,
                        'totalBalance': 1,
                        'mes': 1,
                        'ano': 1
                    }
                }
            ])

        result = [r for r in result]
        if result:
            result = result[0]
            result['transferedAt'] = datetime.datetime.now()
            db_dest.bi_users.insert(result)


if __name__ == '__main__':
    create_user_ebz_reports()

# if __name__ == '__main__':
#     import time
#
#     init = time.time()
#     get_users()
#     print("terminou:", time.time() - init)
