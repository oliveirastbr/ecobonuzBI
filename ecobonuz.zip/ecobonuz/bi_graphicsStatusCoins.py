from pymongo import MongoClient
from bson.objectid import ObjectId
import pendulum
from datetime import datetime, timedelta

# client_orig = MongoClient('mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-prod-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Prod-shard-0&authSource=admin')
# db_orig = client_orig['coin-db']

client_orig = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_orig = client_orig['coin-db']


client_dest = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_dest = client_dest['test']


def create_status():
    startDate = datetime(year=2018,month=3,day=1, hour=0, minute=0, second=0)
    dateFinal = datetime(year=2018, month=3,day=1, hour=23, minute=59, second=59)
    dateActual = datetime.now()
    agora = datetime.now()

    while startDate < dateActual:
        result = db_orig.transactions.aggregate([
            {'$match': {'$type':'addBalance', 'createdAt': {'$gte': startDate, '$lte': dateFinal}}},

            {'$lookup': {'from': 'wallets', 'localField': 'walletId', 'foreignField': '_id', 'as': 'wallet'}},
            {'$unwind': "$wallet"},
            {'$project': {'wallet.chain': 0}},
            {'$lookup': {'from': 'users', 'localField': 'wallet.user', 'foreignField': '_id', 'as': 'user'}},
            {'$unwind': "$user"},
            {'$match': {'user.isPartner': True}},
            {'$group': {
                '_id': {
                    'partner': '$walletId'
                    },
                'partner': {'$first': {'id': '$user._id', 'name': '$user.name'}},
                'avaliable': {'$sum': {"$cond": [
                    {"$and": [{"$in": [ "$description", ['credit']]}]}, '$transactionAmount', 0]}},
                'rescued':  {'$sum': {"$cond": [
                    {"$and": [{"$in":["$description", ["minutradeRescue", "billPaymentRescue","busTicketRescue", "rechargeRescue", "wifiRescue"]]}]}, '$transactionAmount', 0]}}

                # date: { $first: { $concat: [{ $substr: ['$createdAt', 0, 4]}, '-', { $substr: ['$createdAt', 5, 2]}, '-', { $substr: ['$createdAt', 8, 2]}]}}
                }
            },
            {'$project': {
                '_id': False,
                'partner.id': {'$toString': '$partner.id'},
                'partner.name': '$partner.name',
                'avaliable': 1,
                'rescued': 1,
                'outStanding':{'ifNull':['$outStanding', '0']},
                'overdue':{'ifNull': ['$overdue', '0']},
                'pending':{'ifNull': ['$pending', '0']}


                }
            }
        ])
        startDate = startDate + timedelta(month=3)
        dateFinal = dateFinal + timedelta(month=3)
        # dateFinal.setDate(dateFinal.getDate() + 1)
        for r in result:
            try:
                r['transferedAt'] = agora
                db_dest.statusTeste.insert(r)
                print(r)
            except Exception as err:
                print('did not copy card', err)


if __name__ == '__main__':
    import time
    init = time.time()
    create_status()
    print("terminou:", time.time() - init)

