from pymongo import MongoClient
from bson.objectid import ObjectId
import datetime

# client_orig = MongoClient('mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-prod-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Prod-shard-0&authSource=admin')
# db_orig = client_orig['coin-db']

client_orig = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_orig = client_orig['coin-db']


client_dest = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_dest = client_dest['ecobonuzbi']


def create_users():

    result = db_orig.transactions.aggregate([
        {'$match': {
            'type': 'addBalance',
            'description': 'reward'}},
        # {'$limit': 1000},
        {
            '$lookup': {
                'from': 'wallets', 'localField': 'toWallet',
                'foreignField': '_id', 'as': 'userWallet'
            }
        },
        {'$unwind': '$userWallet'},
        {'$project': {'userWallet.chain': 0}},
        {
            '$lookup': {
                'from': 'users', 'localField': 'userWallet.user',
                'foreignField': '_id', 'as': 'partner'
            }
        },
        {'$unwind': '$partner'},
        {
            '$lookup': {
                'from': 'wallets', 'localField': 'walletId',
                'foreignField': '_id', 'as': 'partnerWallet'
            }
        },
        {'$unwind': '$partnerWallet'},
        {'$project': {'partnerWallet.chain': 0}},
        {
            '$lookup': {
                'from': 'users', 'localField': 'partnerWallet.user',
                'foreignField': '_id', 'as': 'user'
                }
        },
        {'$unwind': '$user'},
        {'$group': {
            '_id': '$user._id',
            'name': {'$first': '$user.name'},
            'ein': {'$first': '$user.ein'},
            'email': {'$first': '$user.email'},
            'profileCompleted': {'$first': '$user.profileCompleted'},
            'createdAt': {'$first': '$user.createdAt'},
            'isActive': {'$first': '$user.isActive'},
            'registered': {'$first': 'true'},
            'partners': {
                '$addToSet': {
                    '_id': '$partner._id',
                    'name': '$partner.name'
                    }
                }
            }}
        ])
    for r in result:
        r['transferedAt'] = datetime.datetime.now()
        db_dest.bi_users.insert(r)


if __name__ == '__main__':
    create_users()