from pymongo import MongoClient
from bson.objectid import ObjectId
import pendulum
from datetime import datetime, timedelta

client_orig = MongoClient('mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-prod-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Prod-shard-0&authSource=admin')
db_orig = client_orig['coin-db']

# client_orig = MongoClient(
#     "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
# db_orig = client_orig['coin-db-bi']


client_dest = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_dest = client_dest['test']


def create_accumulate():
    startDate = datetime(year=2018,month=6,day=1, hour=0, minute=0, second=0)
    dateFinal = datetime(year=2018, month=6,day=30, hour=23, minute=59, second=59)
    dateActual = datetime.now()
    agora = datetime.now()

    while startDate < dateFinal:
        result = db_orig.transactions.aggregate([
            {'$match': {'createdAt': {'$gte': startDate, '$lte': dateFinal}}}
        ])
        # startDate = startDate + timedelta(days=1)
        # dateFinal = dateFinal + timedelta(days=1)
        # dateFinal.setDate(dateFinal.getDate() + 1)
        for r in result:
            try:
                r['transferedAt'] = agora
                db_dest.transactions_jun.insert(r)
                print(r)
            except Exception as err:
                print('did not copy card', err)


if __name__ == '__main__':
    import time
    init = time.time()
    create_accumulate()
    print("terminou:", time.time() - init)

