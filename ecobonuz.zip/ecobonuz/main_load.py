from pymongo import MongoClient
from bson.objectid import ObjectId
import datetime
import schedule
import time

# ECOBONUZ PROD
client_orig = MongoClient('mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-prod-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Prod-shard-0&authSource=admin')
db_orig = client_orig['coin-db']

# ECOBONUZ DEV
# mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-test-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-test-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-test-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Test-shard-0&authSource=admin')
# db_orig = client_dest['coin-db']

# client_orig = MongoClient(
#     "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
# db_orig = client_orig['coin-db']


client_dest = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_dest = client_dest['test']


# def get_users():
#     data_ultima = db_dest.users.find({}, {'_id': 0, 'transferedAt': 1}).sort([('transferedAt', -1)]).limit(1)
#
#     for doc in db_orig.users.find():
#         try:
#             doc['transferedAt'] = datetime.datetime.now()
#             db_dest.users.insert(doc)
#             print(doc)
#         except Exception as err:
#             print('did not copy user', err)


def get_bus_cards():
    agora = datetime.datetime.now()
    data_ultima = db_dest.bus_cards.find({}, {'_id': 0, 'transferedAt': 1}).sort([('transferedAt', -1)]).limit(1)

    for doc in db_orig.bus_cards.find({}, {'updatedAt': {'$lt': data_ultima or agora}}):
        doc['transferedAt'] = agora
        try:
            db_dest.bus_cards.insert(doc)
            print(doc)
        except:
            try:
                db_dest.bus_cards.findAndUpdate(doc)
            except Exception as err:
                with open('error_dump.txt', 'a') as arquivo_dump:
                    arquivo_dump.write(err.__str__)


# def get_partners():
#     data_ultima = db_dest.partners.find({}, {'_id': 0, 'transferedAt': 1}).sort([('transferedAt', -1)]).limit(1)
#
#     for doc in db_orig.partners.find():
#         try:
#             doc['transferedAt'] = datetime.datetime.now()
#             db_dest.partners.insert(doc)
#             print(doc)
#         except Exception as err:
#             print('did not copy card', err)
#
#
# def get_transactions():
#     data_ultima = db_dest.transactions.find({}, {'_id': 0, 'transferedAt': 1}).sort([('transferedAt', -1)]).limit(1)
#
#     for doc in db_orig.transactions.find():
#         try:
#             doc['transferedAt'] = datetime.datetime.now()
#             db_dest.transactions.insert(doc)
#             print(doc)
#         except Exception as err:
#             print('did not copy card', err)
#
#
# def get_users_cards_moviments():
#     data_ultima = db_dest.users_cards_moviments.find({}, {'_id': 0, 'transferedAt': 1}).sort([('transferedAt', -1)]).limit(1)
#
#     for doc in db_orig.users_cards_moviments.find():
#         try:
#             doc['transferedAt'] = datetime.datetime.now()
#             db_dest.users_cards_moviments.insert(doc)
#             print(doc)
#         except Exception as err:
#             print('did not copy card', err)
#
#
# def get_rescues():
#     data_ultima = db_dest.rescues.find({}, {'_id': 0, 'transferedAt': 1}).sort([('transferedAt', -1)]).limit(1)
#
#     for doc in db_orig.rescues.find():
#         try:
#             doc['transferedAt'] = datetime.datetime.now()
#             db_dest.rescues.insert(doc)
#             print(doc)
#         except Exception as err:
#             print('did not copy card', err)
#
#
# def get_coins():
#     data_ultima = db_dest.coins.find({}, {'_id': 0, 'transferedAt': 1}).sort([('transferedAt', -1)]).limit(1)
#
#     for doc in db_orig.coins.find():
#         try:
#             doc['transferedAt'] = datetime.datetime.now()
#             db_dest.coins.insert(doc)
#             print(doc)
#         except Exception as err:
#             print('did not copy card', err)


if __name__ == '__main__':
    # get_users()
    # schedule.every().day.at("01:00").do(get_users)
    get_bus_cards()
    # schedule.every().day.at("01:30").do(get_bus_cards)
    # get_partners()
    # # schedule.every().day.at("01:30").do(get_partners)
    # get_transactions()
    # # schedule.every().day.at("01:30").do(get_transactions)
    # get_users_cards_moviments()
    # # schedule.every().day.at("01:30").do(get_users_cards_moviments)
    # get_rescues()
    # # schedule.every().day.at("01:30").do(get_rescues)
    # get_coins()
    # # schedule.every().day.at("01:30").do(get_coins)
    #






