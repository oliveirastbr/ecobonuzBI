from pymongo import MongoClient
from bson.objectid import ObjectId
import datetime
import time

# client_orig = MongoClient('mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-prod-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Prod-shard-0&authSource=admin')
# db_orig = client_orig['coin-db']

client_orig = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_orig = client_orig['coin-db']


client_dest = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_dest = client_dest['ecobonuzbi']


def create_average_ticket():
    agora = datetime.datetime.now()
    result = db_orig.transactions.aggregate([
       {
           '$group': {
               'quantity': {'$sum': 1},
               '_id': '$walletId',
               'realValueAccumulated':{'$sum': '$details.paidValue'},
               'realValueRescued': {'$sum': '$details.cash'},
               'createdAt': {'$first': '$createdAt'},

               'accumulated': {"$sum": { "$cond": [
                       {'$in': ["$type", ["removeBalance"]],
                          '$in': ["$description", ["reward"]],},
                       '$transactionAmount',
                       0
                   ]}},

               'quantityAccumulated': {"$sum": { "$cond": [
                      {'$in': [ "$type", ["removeBalance"] ],
                         '$in': [ "$description", ["reward"] ],},
                      1,
                      0
                  ]}},

               'rescued': {"$sum": { "$cond": [
                       { "$in": [ "$type", ["addBalance"] ],
                          "$in": [ "$description", ["minutradeRescue", "billPaymentRescue","busTicketRescue", "rechargeRescue", "wifiRescue"] ], },
                       '$transactionAmount',
                       0
                   ]}},
               'quantityRescued': {"$sum": {"$cond": [
                       { "$in": ["$type", ["addBalance"] ],
                          "$in": ["$description", ["minutradeRescue", "billPaymentRescue","busTicketRescue", "rechargeRescue", "wifiRescue"] ], },
                       1,
                       0
                   ]}}
               }
           },
       {
           '$lookup': {
               'from': 'wallets', 'localField': '_id',
               'foreignField': '_id', 'as': 'wallet'
           }
       },
       {'$unwind': "$wallet"},
       {'$project': {'wallet.chain': 0}},
       {
           '$lookup': {
               'from': 'users', 'localField': 'wallet.user',
               'foreignField': '_id', 'as': 'partner'
           }
       },
       {'$unwind': "$partner"},
       {'$match': {'partner.isPartner': True}},
       {
           '$project': {
               '_id': 1,
               'quantity': 1,
               'partner.name': 1,
               'partner._id': 1,
               'accumulated': 1,
               'rescued': 1,
               'realValueAccumulated': 1,
               'quantityAccumulated': "$quantityAccumulated",
               'averageTicketAccumulate': {'$cond':  [{'$eq': ["$quantityAccumulated", 0]}, 0,  {'$divide': [ "$realValueAccumulated", '$quantAccumulate' ]}]},
               'realValueRescued':1,
               'quantityRescued': "$quantityRescued",
               'averageTicketRescues': {'$cond':  [{'$eq': ["$quantityRescued", 0]}, 0, {'$divide': ["$realValueRescued", '$quantRescue' ]}]},
               'createdAt': {
                    '$dateToString': {
                        'format': "%d/%m/%Y",
                        'date': "$createdAt"
                        }
                    }
           }

           }

       ])

    for r in result:
        try:
            r['transferedAt'] = agora
            db_dest.graphicsAvarageTicket.insert(r)
            print(r)
        except Exception as err:
            print('did not copy card', err)


if __name__ == '__main__':
    import time
    init = time.time()
    create_average_ticket()
    print("terminou:", time.time() - init)