from pymongo import MongoClient
from bson.objectid import ObjectId
import datetime

# client_orig = MongoClient('mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-prod-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Prod-shard-0&authSource=admin')
# db_orig = client_orig['coin-db']

client_orig = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_orig = client_orig['coin-db']


client_dest = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_dest = client_dest['ecobonuzbi']


def create_partners():
    agora = datetime.datetime.now()
    result = db_orig.partners.aggregate([
        {'$lookup': {
            'from': 'users', 'localField': '_id',
            'foreignField': '_id', 'as': 'userPartner'

        }},
        {'$unwind': '$userPartner'},
        {'$project':{
            '_id':1,
            'name': '$userPartner.name',
            'phone': '$userPartner.phone',
            'commercialPhone':{'$ifNull': ["", ""]},
            'email':'$userPartner.email',
            # "tag": {
            #     "id": 'tag_id',
            #     "name": "tag_name"
            # },
            # 'partner': '$userPartner.partner',
            'partner':{'$ifNull': ["$userPartner.partner", 'null']},
            'accumulate': '$userPartner.partnerInfo.accumulate',
            'rescue': '$userPartner.partnerInfo.rescue',
            'force': {'$ifNull': ['false', '']},
            'createdAt': {
                '$dateToString': {
                'format': "%d/%m/%Y",
                'date': "$userPartner.createdAt"
            }
            },
            # 'totalProduct': { '$cond': { if: { '$isArray': "$userPartner.partnerInfo.rescuesType" }, then: { '$size': "$userPartner.partnerInfo.rescuesType" }, else: "N/A"},
            'totalProduct': {
                '$cond': {'if': {
                    '$isArray': "$userPartner.partnerInfo.rescuesType"
                },
                    'then': {
                        '$size': "$userPartner.partnerInfo.rescuesType"
                    },
                    'else': "N/A"
                }
            }

            }}
        ])

    for r in result:
        r['transferedAt'] = agora
        db_dest.reportsPartners.insert(r)


if __name__ == '__main__':
    create_partners()
