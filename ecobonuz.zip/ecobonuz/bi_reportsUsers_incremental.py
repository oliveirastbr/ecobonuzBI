from pymongo import MongoClient
from bson.objectid import ObjectId
import datetime
import time

# client_orig = MongoClient('mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-prod-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Prod-shard-0&authSource=admin')
# db_orig = client_orig['coin-db']

client_orig = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_orig = client_orig['coin-db']


client_dest = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_dest = client_dest['test']


def create_users_report():
    agora = datetime.datetime.now()
    result = db_orig.users.aggregate([
        # {'$match': {'name': {'$nin': ["Ecobonuz", "Saritur", "Saritur Ipatinga", "Saritur Itauna",
        #                               "Saritur Lavras", "Saritur Timóteo", "Saritur Varginha", "Fabrifacil"]}}},
        {'$lookup': {
            'from': 'wallets','localField': '_id',
            'foreignField': 'user', 'as': 'walletInfo'}},
        {'$unwind': {'path': '$walletInfo', 'preserveNullAndEmptyArrays': True}},
        {'$project': {'walletInfo.chain': 0, 'menu': 0}},
        {'$lookup': {
            'from': 'transactions', 'localField': 'walletInfo._id',
            'foreignField': 'walletId', 'as': 'transactionInfo'}},
        # {'$match':{'transactionInfo.description': 'reward', 'transactionInfo.type': 'addBalance'}},
        {'$addFields': {'lastPoint': {'$arrayElemAt': ['$transactionInfo', -1]}}},
        {'$unwind': {'path': '$lastPoint', 'preserveNullAndEmptyArrays': True}},
        # {'$match': {'partner._id': {'$ne': 'ObjectId("5be96d50d103ce0013046420")'}}},
        {'$lookup': {'from': 'bus_cards', 'localField': '_id', 'foreignField': 'user', 'as': 'cardInfo'}},
        {'$lookup': {
            'from': 'users', 'localField': 'cardInfo.partner',
            'foreignField': '_id', 'as': 'partner'}},
        {'$project': {
            '_id': '$_id',
            'nome': '$name',
            'cpf': '$ein',
            'celular': '$phone',
            'email': '$email',
            # 'cidade': '$city',
            # 'balance': '$walletInfo.balance',
            # 'funcionario': {'$ifNull': ["$isPartnerEmployee", False]},
            'Date': '$createdAt',
            'partner.name': 1,
            'partner._id': 1,
            'profileCompleted': 1,
            'registered': 1,
        }}
    ], allowDiskUse=True)
    resp = []
    i = 0
    for r in result:
        resp.append(r)
        i = i + 1
        if (i % 1000) == 0:
            print(i)
        if i == 250000:
            # print('Starting insert')
            db_dest.usersReport33.insert(resp)

            i = 0
            resp = []
    if i > 0:
        db_dest.usersReport.insert(resp)
        i = 0
        resp = []

        #
        # try:
        #     r['transferedAt'] = agora
        #     db_dest.bi_reportsUsers.insert(r)
        #     print(r)
        # except Exception as err:
        #     print('did not copy card', err)


if __name__ == '__main__':
    import time
    init = time.time()
    create_users_report()
    print("terminou:", time.time() - init)