from pymongo import MongoClient
from bson.objectid import ObjectId
import datetime
import time

# client_orig = MongoClient('mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-prod-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Prod-shard-0&authSource=admin')
# db_orig = client_orig['coin-db']

client_orig = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_orig = client_orig['coin-db']


client_dest = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_dest = client_dest['ecobonuzbi']


def create_store_balance_graph():
    print('aqui')
    data_dest = list(db_dest.reportStoreBalance.find({}, {'_id': 0, 'createdAt': 1}).sort([('createdAt', -1)]).limit(1))[0]
    print(data_dest, 'data_dest')
    data_orig = list(db_orig.cashbacks.find({}, {'_id': 0, 'createdAt': 1}).sort([('createdAt', -1)]).limit(1))[0]
    print(data_orig, 'data_orig')

    formated_data_dest = create_datetime_from_string(data_dest['createdAt'])

    # agora = datetime.datetime.now()
    while formated_data_dest <= data_orig['createdAt']:
        print('oiii')
        result = db_orig.cashbacks.aggregate([
            {'$match': {'createdAt': {'$gt': formated_data_dest}}},
            {'$project': {
                'store':{
                 'id':{'$toString': '$_id'},
                 'name': '$details.storeName',
                },
                'priceValue': '$details.saleValue',
                'coinValue': '$ebzValue',
                'comission': '$commission',
                'createdAt': 1,
                # 'createdAt': {
                #     '$dateToString': {
                #         'format': "%d/%m/%Y",
                #         'date': "$createdAt"
                #         }
                #      },
                'status': 'status'
                }
            }
        ])
        for r in result:
            try:
                # r['transferedAt'] = agora
                db_dest.reportStoreBalance.insert(r)
                print(r)
            except Exception as err:
                print('did not copy card', err)


def create_datetime_from_string(date_in_string):
    date_array = date_in_string.split('/')
    return datetime.datetime(day=int(date_array[0]), month=int(date_array[1]), year=int(date_array[2]))


if __name__ == '__main__':
    import time
    init = time.time()
    create_store_balance_graph()
    print("terminou:", time.time() - init)