from pymongo import MongoClient
from bson.objectid import ObjectId
import datetime
import time

# client_orig = MongoClient('mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuz-prod-shard-00-00-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-01-y0tpt.mongodb.net:27017,ecobonuz-prod-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=Ecobonuz-Prod-shard-0&authSource=admin')
# db_orig = client_orig['coin-db']

client_orig = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_orig = client_orig['coin-db']


client_dest = MongoClient(
    "mongodb://ecobonuz:YsVpXgqFAsgMnzkX@ecobonuzbi-shard-00-00-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-01-y0tpt.mongodb.net:27017,ecobonuzbi-shard-00-02-y0tpt.mongodb.net:27017/coin-db?ssl=true&replicaSet=EcobonuzBI-shard-0&authSource=admin&retryWrites=true")
db_dest = client_dest['test']


def create_average_ticket():
    agora = datetime.datetime.now()
    result = db_orig.transactions.aggregate([
        {'$match':{'$or':[{'description': {'$in':["minutradeRescue", "billPaymentRescue","busTicketRescue", "rechargeRescue", "wifiRescue"]}, 'type': 'removeBalance'},{'description': 'reward', 'type': 'addBalance'}]}},
        {'$lookup': {
            'from': 'wallets', 'localField': 'toWallet',
            'foreignField': '_id', 'as': 'wallet'
        }},
        {'$unwind': '$wallet'},
        {'$lookup': {
            'from': 'users', 'localField': 'wallet.user',
            'foreignField': '_id', 'as': 'partner'
        }},
        {'$unwind': '$partner'},
        {'$group': {
            '_id': {
                'partner': '$partner._id',
                'description': '$description',
                'day': {'$substr': ['$createdAt', 8, 2]},
                'month': {'$substr': ['$createdAt', 5, 2]},
                'year': {'$substr': ['$createdAt', 0, 4]}
                },
            'partner': {'$first': {'id': '$partner._id', 'name': '$partner.name'}},
            'description': {'$last': '$description'},
            'realValue': {'$sum':  '$details.paidValue'},
            'valor':{'$sum': {'$toDouble': '$details.paidValue'}},
            'coinValue': {'$sum': '$transactionAmount'},
           # totalAccumulate:  { $sum: { $cond: [ { $eq: [ "$type", 'addBalance' ] }, '$transactionAmount', 0 ] } },
           # totalRescues:  { $sum: { $cond: [ { $eq: [ "$type", 'removeBalance' ] }, '$transactionAmount', 0 ] } },
            'transactionsQuantity': {'$sum': 1 },
            'date': {'$first': {'$concat': [ {'$substr': ['$createdAt', 0, 4]}, '-', {'$substr': ['$createdAt', 5, 2]}, '-', {'$substr': ['$createdAt', 8, 2] } ] } }
            }
        },
        {'$project': {
            '_id': False,
            'partner.id': {'$toString': '$partner.id' },
            'partner.name': '$partner.name',
            'description': 1,
            'realValue': 1,
            'coinValue': 1,
            'valor':1,
            'totalAccumulate':1,
            'totalRescues':1,
            'transactionsQuantity': 1,
            'date': {'$dateFromString': {'dateString': '$date'}}
        }}
    ])

    for r in result:
        try:
            r['transferedAt'] = agora
            db_dest.bi_averageTicket_graph.insert(r)
            print(r)
        except Exception as err:
            print('did not copy card', err)


if __name__ == '__main__':
    import time
    init = time.time()
    create_average_ticket()
    print("terminou:", time.time() - init)